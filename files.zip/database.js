/**
 * database.js
 * Tries better-sqlite3 first; falls back to a JSON file if unavailable.
 */

const path = require('path');
const fs   = require('fs');

const JSON_PATH = path.join(__dirname, 'ideas.json');
let db       = null;
let useJSON  = false;

// ─── SQLite setup ────────────────────────────────────────────────────────────
function initSQLite() {
  const Database = require('better-sqlite3');
  db = new Database(path.join(__dirname, 'ideas.db'));
  db.exec(`
    CREATE TABLE IF NOT EXISTS ideas (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      name              TEXT NOT NULL,
      email             TEXT NOT NULL,
      idea_title        TEXT NOT NULL,
      idea_description  TEXT NOT NULL,
      problem           TEXT,
      industry          TEXT,
      stage             TEXT,
      skills            TEXT,
      collaborator_need TEXT,
      commitment        TEXT,
      target_audience   TEXT,
      created_at        TEXT DEFAULT (datetime('now'))
    )
  `);
  console.log('✅  Using SQLite (better-sqlite3)');
}

// ─── JSON fallback setup ──────────────────────────────────────────────────────
function initJSON() {
  useJSON = true;
  if (!fs.existsSync(JSON_PATH)) {
    fs.writeFileSync(JSON_PATH, JSON.stringify([]));
  }
  console.log('ℹ️   SQLite unavailable — using JSON file fallback');
}

// ─── Public init ─────────────────────────────────────────────────────────────
function initDB() {
  try {
    initSQLite();
  } catch (_) {
    initJSON();
  }
}

// ─── CRUD helpers ─────────────────────────────────────────────────────────────
function getAllIdeas() {
  if (useJSON) {
    return JSON.parse(fs.readFileSync(JSON_PATH, 'utf8'));
  }
  return db.prepare('SELECT * FROM ideas ORDER BY created_at DESC').all();
}

function getIdeaById(id) {
  if (useJSON) {
    return getAllIdeas().find(i => i.id === id) || null;
  }
  return db.prepare('SELECT * FROM ideas WHERE id = ?').get(id) || null;
}

function addIdea(data) {
  const row = {
    name:              data.name              || '',
    email:             data.email             || '',
    idea_title:        data.idea_title        || '',
    idea_description:  data.idea_description  || '',
    problem:           data.problem           || '',
    industry:          data.industry          || 'Other',
    stage:             data.stage             || 'Just an idea',
    skills:            data.skills            || '',
    collaborator_need: data.collaborator_need || 'Any',
    commitment:        data.commitment        || '5–10hrs',
    target_audience:   data.target_audience   || '',
    created_at:        new Date().toISOString(),
  };

  if (useJSON) {
    const ideas = getAllIdeas();
    const id    = ideas.length ? Math.max(...ideas.map(i => i.id)) + 1 : 1;
    ideas.push({ id, ...row });
    fs.writeFileSync(JSON_PATH, JSON.stringify(ideas, null, 2));
    return id;
  }

  const result = db.prepare(`
    INSERT INTO ideas
      (name, email, idea_title, idea_description, problem, industry, stage,
       skills, collaborator_need, commitment, target_audience, created_at)
    VALUES
      (@name, @email, @idea_title, @idea_description, @problem, @industry,
       @stage, @skills, @collaborator_need, @commitment, @target_audience, @created_at)
  `).run(row);
  return result.lastInsertRowid;
}

// ─── Seed data ────────────────────────────────────────────────────────────────
const SEEDS = [
  {
    name: 'Amara Osei', email: 'amara@example.com',
    idea_title: 'PlantPal', idea_description: 'AI-powered app that diagnoses plant diseases from photos and recommends personalised care routines.',
    problem: 'Plant owners struggle to identify diseases and know when to water, fertilise, or repot their plants.',
    industry: 'Tech', stage: 'Have a plan',
    skills: 'Mobile development, machine learning, UX design',
    collaborator_need: 'Business', commitment: '10+ hrs',
    target_audience: 'Home gardeners, plant enthusiasts, apartment dwellers',
  },
  {
    name: 'Marcus Chen', email: 'marcus@example.com',
    idea_title: 'TutorLink', idea_description: 'Peer-to-peer tutoring marketplace where college students earn by teaching what they know.',
    problem: 'Students cannot afford professional tutors, and high-achievers have no way to monetise their knowledge.',
    industry: 'Education', stage: 'Already started',
    skills: 'Business development, marketing, product strategy',
    collaborator_need: 'Technical', commitment: '10+ hrs',
    target_audience: 'College students, high school students, universities',
  },
  {
    name: 'Priya Sharma', email: 'priya@example.com',
    idea_title: 'FoodLoop', idea_description: 'Platform connecting restaurants with surplus food to nearby food banks and community fridges in real time.',
    problem: 'Tons of edible food is wasted daily by restaurants while local communities face food insecurity.',
    industry: 'Social', stage: 'Just an idea',
    skills: 'Operations, community organising, data analysis',
    collaborator_need: 'Technical', commitment: '5–10hrs',
    target_audience: 'Restaurants, food banks, local communities, volunteers',
  },
  {
    name: 'Jordan Wells', email: 'jordan@example.com',
    idea_title: 'MicroVest', idea_description: 'Gamified micro-investing app for Gen Z that turns spare change into diversified portfolios.',
    problem: 'Young adults feel excluded from investing because of high minimums and intimidating jargon.',
    industry: 'Finance', stage: 'Have a plan',
    skills: 'Financial modelling, investment strategy, compliance',
    collaborator_need: 'Technical', commitment: '10+ hrs',
    target_audience: 'Gen Z, millennials, first-time investors, students',
  },
  {
    name: 'Sofia Mendez', email: 'sofia@example.com',
    idea_title: 'MindJournal', idea_description: 'AI-guided mental health journaling app with mood tracking, pattern recognition, and therapist matching.',
    problem: 'Mental health support is inaccessible due to cost and stigma — people need a low-barrier first step.',
    industry: 'Health', stage: 'Already started',
    skills: 'Psychology, content writing, UX research',
    collaborator_need: 'Technical', commitment: '10+ hrs',
    target_audience: 'Adults 18–40, therapy-curious individuals, corporate employees',
  },
  {
    name: 'Kwame Asante', email: 'kwame@example.com',
    idea_title: 'LinguaLink', idea_description: 'AI conversation partner for language learners that adapts to your pace and corrects mistakes in real time.',
    problem: 'Language apps teach vocabulary but not real conversation; learners plateau without speaking practice.',
    industry: 'Education', stage: 'Just an idea',
    skills: 'Linguistics, curriculum design, teaching experience',
    collaborator_need: 'Technical', commitment: '5–10hrs',
    target_audience: 'Language learners, expats, students, professionals',
  },
  {
    name: 'Rachel Torres', email: 'rachel@example.com',
    idea_title: 'FreelanceFlow', idea_description: 'Financial planning tool built for freelancers to handle taxes, invoicing, and irregular income intelligently.',
    problem: 'Freelancers struggle with unpredictable cash flow, self-employment taxes, and retirement planning.',
    industry: 'Finance', stage: 'Have a plan',
    skills: 'Accounting, freelance experience, user research',
    collaborator_need: 'Technical', commitment: '5–10hrs',
    target_audience: 'Freelancers, consultants, gig workers, solopreneurs',
  },
  {
    name: 'Lena Fischer', email: 'lena@example.com',
    idea_title: 'ThreadCycle', idea_description: 'Sustainable fashion marketplace where users can swap, rent, and upcycle clothing to cut textile waste.',
    problem: 'Fast fashion creates massive environmental damage while consumers want affordable sustainable options.',
    industry: 'Social', stage: 'Just an idea',
    skills: 'Fashion industry knowledge, sustainability, brand building',
    collaborator_need: 'Technical', commitment: '5–10hrs',
    target_audience: 'Eco-conscious shoppers, young adults, fashion enthusiasts',
  },
  {
    name: 'David Kim', email: 'david@example.com',
    idea_title: 'SkillSwap Local', idea_description: 'Neighbourhood platform where residents exchange skills — baking for coding, guitar for gardening — no money needed.',
    problem: 'Community connections are eroding in the digital age; people have skills to share but no way to meet neighbours.',
    industry: 'Social', stage: 'Have a plan',
    skills: 'Community building, marketing, local partnerships',
    collaborator_need: 'Technical', commitment: '5–10hrs',
    target_audience: 'Local residents, retirees, young professionals, families',
  },
  {
    name: 'Aisha Okonkwo', email: 'aisha@example.com',
    idea_title: 'FocusForge', idea_description: 'Deep-work productivity suite for remote teams with smart scheduling, focus sessions, and async collaboration.',
    problem: 'Remote workers face constant interruptions and lack structured deep-work time in distributed teams.',
    industry: 'Tech', stage: 'Already started',
    skills: 'Product management, remote work expertise, user research',
    collaborator_need: 'Technical', commitment: '10+ hrs',
    target_audience: 'Remote workers, distributed teams, startup founders, knowledge workers',
  },
];

function seedIfEmpty() {
  const ideas = getAllIdeas();
  if (ideas.length === 0) {
    console.log('🌱  Seeding database with 10 example ideas…');
    SEEDS.forEach(s => addIdea(s));
    console.log('✅  Seed complete');
  }
}

module.exports = { initDB, seedIfEmpty, getAllIdeas, getIdeaById, addIdea };
