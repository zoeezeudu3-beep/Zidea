/**
 * matcher.js
 * Scores every stored idea against a target idea and returns the top 3.
 *
 * Scoring weights (max 100 pts):
 *   Industry / category match    — 40 pts
 *   Collaborator need ↔ skills   — 20 pts
 *   Target-audience keyword overlap — 25 pts
 *   Stage proximity              —  8 pts
 *   Commitment proximity         —  7 pts
 */

const { getAllIdeas, getIdeaById } = require('./database');

// ─── Tokeniser ────────────────────────────────────────────────────────────────
const STOP_WORDS = new Set([
  'the','a','an','and','or','for','to','in','of','with','that','are',
  'is','it','on','at','by','as','be','we','our','my','your','their',
  'this','these','those','can','will','but','not','from','they','who',
  'how','what','have','had','has','do','does','did','been',
]);

function tokenize(text) {
  if (!text) return [];
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !STOP_WORDS.has(w));
}

// Jaccard-style overlap ratio
function overlapRatio(setA, setB) {
  if (!setA.length || !setB.length) return 0;
  const intersection = setA.filter(t => setB.includes(t)).length;
  const union = new Set([...setA, ...setB]).size;
  return intersection / union;
}

// ─── Core scorer ──────────────────────────────────────────────────────────────
const STAGES    = ['Just an idea', 'Have a plan', 'Already started'];
const COMMIT    = ['< 5hrs', '5–10hrs', '10+ hrs'];
const COLLAB_SCORES = {
  exact: 20,   // both want same type
  any:   14,   // at least one says "Any"
  none:   0,
};

function computeScore(idea, candidate) {
  let score = 0;
  const sharedTags = [];

  // ── 1. Industry (40 pts) ──────────────────────────────────────────────────
  if (idea.industry && idea.industry === candidate.industry) {
    score += 40;
    sharedTags.push(idea.industry);
  }

  // ── 2. Collaborator need ↔ skills (20 pts) ────────────────────────────────
  // Directional: does what candidate offers match what idea needs (and vice-versa)?
  const needA  = (idea.collaborator_need  || '').toLowerCase();
  const needB  = (candidate.collaborator_need || '').toLowerCase();

  if (needA === 'any' || needB === 'any') {
    score += COLLAB_SCORES.any;
  } else if (needA === needB) {
    // Both looking for same type — they complement each other
    score += COLLAB_SCORES.exact;
    sharedTags.push(idea.collaborator_need);
  } else {
    // Partial: check if idea's needed type is in candidate's skills and vice-versa
    const skillsA = tokenize(idea.skills);
    const skillsB = tokenize(candidate.skills);
    const needATokens = tokenize(idea.collaborator_need);
    const needBTokens = tokenize(candidate.collaborator_need);

    const fwd = overlapRatio(needATokens, skillsB);
    const bwd = overlapRatio(needBTokens, skillsA);
    const partialScore = Math.round(((fwd + bwd) / 2) * 20);
    score += partialScore;

    // Surface shared skills as tags
    const overlap = skillsA.filter(t => skillsB.includes(t));
    overlap.slice(0, 2).forEach(t => sharedTags.push(t));
  }

  // ── 3. Target-audience keyword overlap (25 pts) ───────────────────────────
  const audA = tokenize(idea.target_audience);
  const audB = tokenize(candidate.target_audience);
  const audRatio = overlapRatio(audA, audB);
  const audScore = Math.round(audRatio * 25);
  score += audScore;

  const audOverlap = audA.filter(t => audB.includes(t));
  audOverlap.slice(0, 3).forEach(t => sharedTags.push(t));

  // ── 4. Stage proximity (8 pts) ────────────────────────────────────────────
  const stageIdxA = STAGES.indexOf(idea.stage);
  const stageIdxB = STAGES.indexOf(candidate.stage);
  if (stageIdxA !== -1 && stageIdxB !== -1) {
    const d = Math.abs(stageIdxA - stageIdxB);
    score += d === 0 ? 8 : d === 1 ? 4 : 0;
    if (d === 0) sharedTags.push(idea.stage);
  }

  // ── 5. Commitment proximity (7 pts) ──────────────────────────────────────
  const commitIdxA = COMMIT.indexOf(idea.commitment);
  const commitIdxB = COMMIT.indexOf(candidate.commitment);
  if (commitIdxA !== -1 && commitIdxB !== -1) {
    const d = Math.abs(commitIdxA - commitIdxB);
    score += d === 0 ? 7 : d === 1 ? 3 : 0;
    if (d === 0) sharedTags.push(idea.commitment + '/wk');
  }

  // Deduplicate and tidy tags
  const uniqueTags = [...new Set(sharedTags)]
    .filter(Boolean)
    .map(t => t.charAt(0).toUpperCase() + t.slice(1))
    .slice(0, 5);

  const MAX = 40 + 20 + 25 + 8 + 7; // = 100
  const percentage = Math.min(100, Math.round((score / MAX) * 100));

  return { score: percentage, tags: uniqueTags };
}

// ─── Public API ───────────────────────────────────────────────────────────────
function findMatches(ideaId) {
  const idea = getIdeaById(ideaId);
  if (!idea) return [];

  const all    = getAllIdeas();
  const others = all.filter(i => i.id !== Number(ideaId));

  const scored = others
    .map(candidate => {
      const { score, tags } = computeScore(idea, candidate);
      return {
        id:               candidate.id,
        name:             candidate.name,
        email:            candidate.email,
        idea_title:       candidate.idea_title,
        idea_description: candidate.idea_description,
        industry:         candidate.industry,
        stage:            candidate.stage,
        commitment:       candidate.commitment,
        collaborator_need: candidate.collaborator_need,
        matchScore:       score,
        sharedTags:       tags,
      };
    })
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, 3);

  return scored;
}

module.exports = { findMatches };
