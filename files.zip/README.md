# 💡 IdeaMatch — Idea Collaboration Matcher

Find co-founders and collaborators who complement your vision.

## Features

- **Idea submission** with name, email, title, and description
- **7-question questionnaire** covering problem, industry, stage, skills, collaborator needs, commitment, and target audience
- **Similarity matching engine** (100-point scoring across 5 weighted dimensions)
- **Top-3 match results** with score rings, shared tags, and one-click email reveal
- **Admin panel** at `/#admin` listing all submitted ideas with search/filter
- **10 seed ideas** pre-loaded so matching works on first run
- SQLite via `better-sqlite3` with automatic JSON fallback if SQLite is unavailable

---

## Quick Start

### 1. Install dependencies

```bash
cd idea-matcher
npm install
```

### 2. Start the server

```bash
npm start
# or for auto-reload during development:
npm run dev
```

### 3. Open your browser

```
http://localhost:3000        ← Main app
http://localhost:3000/#admin ← Admin panel
```

The database is seeded automatically on first run with 10 example ideas.

---

## Project Structure

```
idea-matcher/
├── server.js          ← Express API server
├── database.js        ← SQLite / JSON storage + seed data
├── matcher.js         ← Similarity scoring engine
├── package.json
├── public/
│   └── index.html     ← React SPA (single file, no build step)
├── ideas.db           ← Created on first run (SQLite)
└── ideas.json         ← Created on first run (JSON fallback)
```

---

## API Endpoints

| Method | Path              | Description                              |
|--------|-------------------|------------------------------------------|
| POST   | `/api/ideas`      | Submit idea → returns `{ id, matches }` |
| GET    | `/api/ideas`      | List all ideas (admin)                   |
| GET    | `/api/ideas/:id`  | Get a single idea by ID                  |
| GET    | `/api/matches/:id`| Get top-3 matches for an existing idea   |

---

## Matching Algorithm

Scores are out of 100:

| Dimension                       | Weight |
|---------------------------------|--------|
| Industry / category match       | 40 pts |
| Collaborator need ↔ skills      | 20 pts |
| Target-audience keyword overlap | 25 pts |
| Stage proximity                 |  8 pts |
| Commitment level proximity      |  7 pts |

---

## Tech Stack

- **Frontend**: React 18 (CDN) + Tailwind CSS (CDN) + Babel Standalone
- **Backend**: Node.js + Express
- **Database**: better-sqlite3 (with JSON file fallback)
- No build step required — just `npm install && npm start`
