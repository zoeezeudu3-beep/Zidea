/**
 * server.js — Idea Collaboration Matcher API
 */

const express = require('express');
const cors    = require('cors');
const path    = require('path');

const { initDB, seedIfEmpty, getAllIdeas, getIdeaById } = require('./database');
const { findMatches } = require('./matcher');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ──────────────────────────────────────────────────────────────────────────────
// API Routes
// ──────────────────────────────────────────────────────────────────────────────

// Submit a new idea → returns id + top-3 matches
app.post('/api/ideas', (req, res) => {
  try {
    const { addIdea } = require('./database');
    const id      = addIdea(req.body);
    const matches = findMatches(id);
    res.json({ success: true, id, matches });
  } catch (err) {
    console.error('POST /api/ideas error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// List all ideas (admin)
app.get('/api/ideas', (_req, res) => {
  try {
    res.json(getAllIdeas());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get a single idea
app.get('/api/ideas/:id', (req, res) => {
  try {
    const idea = getIdeaById(Number(req.params.id));
    if (!idea) return res.status(404).json({ error: 'Not found' });
    res.json(idea);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get top-3 matches for an existing idea
app.get('/api/matches/:id', (req, res) => {
  try {
    const matches = findMatches(Number(req.params.id));
    res.json(matches);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Catch-all: serve the SPA
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ──────────────────────────────────────────────────────────────────────────────
// Boot
// ──────────────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;

initDB();
seedIfEmpty();

app.listen(PORT, () => {
  console.log(`\n🚀  Idea Matcher running → http://localhost:${PORT}`);
  console.log(`📋  Admin panel         → http://localhost:${PORT}/#admin\n`);
});
